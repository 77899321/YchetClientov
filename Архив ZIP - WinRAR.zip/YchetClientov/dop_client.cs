﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YchetClientov
{
    public partial class client
    {
        public string category
        {
            get
            {
                //отображает выполнено или не выполнено вместо id  бд
                var cat = App.DB.category.FirstOrDefault(p => p.id == id_category);
                return cat.name;
            }
        }
    }
}
